# AutoShell Studio v3
Complete stronger demo: glassmorphism UI, onboarding/roles, sign-in/sign-out demo, projects, individual/group projects, natural-language command assistant, live suggestions, typo correction, command copy, risk labels, safety blocker, interactive terminal, command history, project/team tracking, workflows and scheduler.

## Frontend
```powershell
npm install
npm run dev
```
Open http://localhost:5173

## Backend
In a second terminal:
```powershell
cd backend
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn main:app --reload --port 8000
```

## Professor demo
1. Create a Group project.
2. Assistant → type `I want to save my project`.
3. Show git add / commit / push suggestions.
4. Type `gti status` → show typo correction.
5. Run `git status`.
6. Open Command History → project/user/time/result.
7. Team Activity → collaborators.
8. Workflows → Save project.
9. Scheduler → daily checkpoint.
10. Terminal → try `rm -rf /` and show safety block.

For OSSP explanation, connect this web layer to your Linux shell concepts: parsing, fork(), exec(), waitpid(), filesystem operations and automation. Do not claim the browser itself is calling Linux syscalls.
