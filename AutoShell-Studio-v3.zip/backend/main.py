
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime
import re, platform

app=FastAPI(title="AutoShell Command Intelligence API",version="3.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
projects=[{"id":"p1","name":"AutoShell","type":"Group","progress":72,"status":"Active","started":"Oct 08, 2026","members":["Varshitha","Akhila","Rishitha"],"commands":18,"correct":15,"wrong":3}]
history=[]
blocked=re.compile(r"(rm\s+-rf|mkfs|shutdown|reboot|format|diskpart)",re.I)
fixes={"gti":"git","giit":"git","mkdr":"mkdir","mkrdir":"mkdir","touchh":"touch","pyhton":"python","nmp":"npm","pwwd":"pwd"}

class Project(BaseModel):
    id:str|None=None;name:str;type:str="Individual";progress:int=0;status:str="Active";started:str|None=None;members:list[str]=[];commands:int=0;correct:int=0;wrong:int=0
class Cmd(BaseModel):
    command:str;project:str="AutoShell";user:str="User"
class Query(BaseModel): text:str

@app.get("/api/health")
def health(): return {"ok":True,"service":"AutoShell backend","platform":platform.system(),"time":datetime.now().isoformat()}
@app.get("/api/projects")
def get_projects(): return {"projects":projects}
@app.post("/api/projects")
def add_project(p:Project):
    p.id=p.id or f"p{len(projects)+1}";p.started=p.started or datetime.now().strftime("%b %d, %Y");projects.insert(0,p.model_dump());return p
@app.post("/api/commands/suggest")
def suggestions(q:Query):
    s=[];x=q.text.lower()
    if any(k in x for k in ["save","backup","store"]):s += [["git add .","Stage current changes","low"],['git commit -m "Update project"',"Create checkpoint","medium"],["git push","Upload committed changes","medium"]]
    if any(k in x for k in ["update","change","sync"]):s += [["git status","Inspect changes","low"],["git add .","Stage updated files","low"]]
    if "create" in x or "new project" in x:s += [["mkdir MyProject","Create project directory","low"],["mkdir src docs tests","Create standard folders","low"]]
    if "git" in x or "status" in x:s += [["git status","Show repository state","low"]]
    if "disk" in x or "space" in x:s += [["df -h","Show filesystem usage","low"]]
    return {"suggestions":s[:6]}
@app.post("/api/commands/execute")
def execute(c:Cmd):
    original=c.command.strip();fixed=original;parts=original.split()
    if parts and parts[0].lower() in fixes: fixed=fixes[parts[0].lower()]+original[len(parts[0]):]
    bad=bool(blocked.search(fixed))
    out={"command":original,"executed":fixed,"project":c.project,"user":c.user,"time":datetime.now().isoformat(timespec="seconds"),"status":"Blocked" if bad else "Success"}
    out["output"]="Safety policy blocked a destructive command." if bad else f"Demo execution accepted: {fixed}"
    history.append(out);return out
@app.get("/api/history")
def get_history():return {"history":history}
@app.get("/api/stats")
def stats():return {"executed":len(history),"success":sum(x["status"]=="Success" for x in history),"blocked":sum(x["status"]=="Blocked" for x in history)}
