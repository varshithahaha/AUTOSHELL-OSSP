# AutoShell Backend
Run:
```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m uvicorn main:app --reload --port 8000
```
Endpoints: `/api/health`, `/api/projects`, `/api/commands/suggest`, `/api/commands/execute`, `/api/history`, `/api/stats`.
Execution is intentionally restricted for safety; this is the command-intelligence web layer, not arbitrary remote shell access.
